using UnityEngine;

public class Bullet : MonoBehaviour
{
	// 球のスピード
	public int speed = 10;
	
	// 弾が表示された時に呼び出される
	void OnEnable ()
	{
		// 弾の移動
		rigidbody2D.velocity = transform.up.normalized * speed;
	}

	// 弾が何らかのトリガーに当たった時に呼び出される
	void OnTriggerExit2D (Collider2D other)
	{
		// 弾の削除。実際には非アクティブにする
		ObjectPool.instance.ReleaseGameObject (gameObject);
	}
}